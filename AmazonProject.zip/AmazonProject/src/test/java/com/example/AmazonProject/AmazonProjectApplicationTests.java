package com.example.AmazonProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
